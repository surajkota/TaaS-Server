Files are in:
bootstrap-3.3.7 > docs > examples > Taas

The html and css were modified from one of the example templates